# YiXiaoBan
The Software Engineering Final Project.

***

## Team Member
Yi Liu, Ziheng Ni, Chenxu Hu, Zhicheng Pi.

## Tools
### Front End
HTML5, CSS3, JavaScript, BootStrap/Amaze UI or Semantic UI

Actually We may try to use Semantic UI


