$(function () {
    $(window).scroll(function (event) {
        var winPos = $(window).scrollTop();
        if (winPos > 0) {
            $("header").removeClass("am-topbar-haha");
            $("#search").removeAttr("hidden");
            $("#white0").removeClass("am-btn-white");
            $("#white0").addClass("am-btn-gray");
            $("#white1").removeClass("am-btn-white");
            $("#white1").addClass("am-btn-gray");
            $("#white2").removeClass("am-btn-white");
            $("#white2").addClass("am-btn-gray");
            $("#white3").removeClass("am-btn-white");
            $("#white3").addClass("am-btn-gray");
        } else {
            $("header").addClass("am-topbar-haha");
            $("#search").attr("hidden", "hidden");
            $("#white0").removeClass("am-btn-gray");
            $("#white0").addClass("am-btn-white");
            $("#white1").removeClass("am-btn-gray");
            $("#white1").addClass("am-btn-white");
            $("#white2").removeClass("am-btn-gray");
            $("#white2").addClass("am-btn-white");
            $("#white3").removeClass("am-btn-gray");
            $("#white3").addClass("am-btn-white");
        }
    });
});